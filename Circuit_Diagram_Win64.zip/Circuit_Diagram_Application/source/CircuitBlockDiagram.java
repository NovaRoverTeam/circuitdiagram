import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class CircuitBlockDiagram extends PApplet {

final int NUM_OF_NODES = 10;
final int NODE_WIDTH = 180;
final int NODE_HEIGHT = 150;
final int NODE_BORDER_THICKNESS = 5;

final int NUM_OF_CONNECTORS = 12;
final int CONNECTOR_THICKNESS = 5;

final float EXPAND_MOVE_STEP = 20.0f; 
final int EXPAND_WIDTH_STEP = 20;
final int EXPAND_HEIGHT_STEP = 15;
final int EXPANDED_SIZE_INCREASE = 600;

boolean global_lock_disabled = true;
int activated_node = -1;

PImage encoder_img, kicad_img, kicad_img_gray, chrome_img, chrome_img_gray;

Node[] nodes; 
Connector[] connectors;

public void setup() {
  
  frameRate(60);
  
  background(255);
  kicad_img = loadImage("icons/kicad_icon.png");
  chrome_img = loadImage("icons/chrome_icon.png");
  kicad_img.resize(0,25);
  chrome_img.resize(0,27);
  kicad_img_gray = loadImage("icons/kicad_icon.png");
  kicad_img_gray.resize(0,25);
  kicad_img_gray.filter(GRAY);
  chrome_img_gray = loadImage("icons/chrome_icon.png");
  chrome_img_gray.resize(0,27);
  chrome_img_gray.filter(GRAY);
  nodes = new Node[NUM_OF_NODES];
  connectors = new Connector[NUM_OF_CONNECTORS];
  CreateNodes();
  CreateConnectors();
}

public void draw() {
  background(255);
  UpdateNodes();
  DisplayConnectors();
  DisplayNodes();
}

public void UpdateNodes() {
  for (int i=0; i<NUM_OF_NODES; i++) {
    nodes[i].CheckRollover();
  }
}

public void DisplayNodes() {
  int expanded_node_id = -1;
  for (int i=0; i<NUM_OF_NODES; i++) {
    if(nodes[i].node_activated) {
      expanded_node_id = i;
    }
    else { 
      nodes[i].Display();
    }
  }
  if(expanded_node_id != -1) {
    nodes[expanded_node_id].Display();
  }
}

public void UpdatePositions(float delta_x, float delta_y) {
    for (int i = 0; i < NUM_OF_NODES; i++) {
      nodes[i].UpdatePosition(delta_x, delta_y);
    }
    for (int i = 0; i < NUM_OF_CONNECTORS; i++) {
      connectors[i].UpdatePosition(delta_x, delta_y);
    }
}

public void DisplayConnectors() {
  for (int i=0; i<NUM_OF_CONNECTORS; i++) {
    connectors[i].Display();
  }
}

public void mouseDragged() {
  float x_diff = mouseX-pmouseX;
  float y_diff = mouseY-pmouseY;
  if(global_lock_disabled) { 
    UpdatePositions(x_diff, y_diff);
  }
  else if(nodes[activated_node].display_image == true) {
    nodes[activated_node].UpdateImagePosition(x_diff, y_diff);
  }
}

public void mousePressed() {
  if(global_lock_disabled) {
    for (int i = 0; i < NUM_OF_NODES; i++) {
      if(nodes[i].mouse_is_over)
      {
        activated_node = i;
        nodes[i].node_activated = true;
        global_lock_disabled = false;
        for (int j = 0; j < nodes[activated_node].connector_id_array.length; j++) {
          if(nodes[activated_node].connector_id_array[j] == -1)
          {
            break;
          }
          else {
            connectors[nodes[activated_node].connector_id_array[j]].is_visible = false;
          }
        }
        break;
      }
    }
  }
  else {
    if (!nodes[activated_node].MouseIsInsideNode() && !nodes[activated_node].display_image) {
      nodes[activated_node].node_expanded = false;
      nodes[activated_node].reduce_node = true;
    }
    else {
      if(nodes[activated_node].display_image) {
        if(nodes[activated_node].mouse_over_arrow) {
          nodes[activated_node].display_image = false;
        }
      }
      else if(nodes[activated_node].mouse_over_kicad && nodes[activated_node].kicad_enabled) {
        nodes[activated_node].display_image = true;
      }
      else if(nodes[activated_node].mouse_over_chrome) {
        nodes[activated_node].OpenLinks();
      }
    }
  }
}
public void CreateNodes() {
  nodes[0] = new Node(0, 200, 200, NODE_WIDTH, NODE_HEIGHT, "MOTORS & ENCODERS SYSTEM");
  nodes[0].AddLink("https://www.servocity.com/118-rpm-hd-premium-planetary-gear-motor-w-encoder");
  nodes[0].AddLink("https://learn.sparkfun.com/tutorials/pro-micro--fio-v3-hookup-guide/hardware-overview-pro-micro");
  nodes[0].AddImage("schematics/Encoders.png");
  nodes[0].CONTENTS_SIZE = 15;
  nodes[0].AddContents("This system emcompasses the motors which drive the wheels of the rover, as well as the encoder chips used to obtain feedback from the wheels.\n\nThe motors receive regulated power from the motor drivers to rotate the wheels at the speed set by the user, with a maximum speed of 118 RPM.\n\nThe encoders attached to each motor permit the measurement and calculation of the wheel\u2019s respective speed. Hall Effect sensors measure the polarity of a section of a magnetic disk attached to the motor shaft and correspondingly output a HIGH or LOW signal.\n\nThese signals are read by an Arduino Pro Micro, which uses the number of pulses over a period of time to calculate how fast the magnetic disk is moving and, therefore, the speed of the shaft and connected wheel. The RPM calculations are then shared to the Raspberry Pi using ROS.");
  
  nodes[1] = new Node(1, 600, 400, NODE_WIDTH, NODE_HEIGHT, "RASPBERRY PI");
  nodes[1].AddLink("https://i.stack.imgur.com/sVvsB.jpg");
  nodes[1].AddImage("schematics/RaspberryPi.png");
  nodes[1].CONTENTS_SIZE = 15;
  nodes[1].AddContents("The Raspberry Pi is a minature computer that serves as the main processor of the rover, equating it to something similar to a \u201cbrain\u201d for the system. The Pi\u2019s balance between portability, cost, power consumption, processing power and available documentation distininguish the board as the superior choice for onboard processing.\n\nThe Pi is connected to every component on the rover in some manner and is able to use various communication mediums to retrieve data or send commands to them, including GPIO pins, UART and i2c. The Pi also serves as the entry point for bi-directional communcation with the base station, broadcasting and receiving information via an on-board radio.\n\nIn addition, the Pi uses ROS (Robot Operating System) to facilitate inter-component communications. ROS establishes a modular and robust framework primarily used for inter-component communcation.");
  
  nodes[2] = new Node(2, 1000, 200, NODE_WIDTH, NODE_HEIGHT, "GPS MODULE");
  nodes[2].AddLink("https://www.robotshop.com/en/uart-neo-7m-c-gps-module.html");
  nodes[2].ShareImage(nodes[1]);
  nodes[2].AddContents("The GPS module uses transmissions from satellites orbiting Earth to obtain the latitude and longitude coordinates of the component.\n\nThe module receives power from the Raspberry Pi and sends coordinate data to it via UART. If the module is unable to obtain position data, the red LED on the module will remain solid. On the other hand, the red LED will blink at 1 Hz if data is available.");
  
  nodes[3] = new Node(3, 600, 600, NODE_WIDTH, NODE_HEIGHT, "16-CHANNEL PWM DRIVER");
  nodes[3].AddLink("https://www.adafruit.com/product/815");
  nodes[3].ShareImage(nodes[1]);
  nodes[3].AddContents("The Pulse Width Modulation (PWM) driver receives desired PWM signals to be generated and outputs the required signals to a maximum of 16 channels.\n\nOnly 4 PWM channels are presently used on the rover \u2013 one channel for each wheel. The PWM signals to be generated is communicated from the Raspberry Pi via i2c and the PWM signals are generated depending on the desired speed of the wheels, with higher duty cycles corresponding to higher speeds.\n\nFinally, the generated PWM signals are output to the motor drivers for each corresponding motor.");
  
  nodes[4] = new Node(4, 200, 400, NODE_WIDTH, NODE_HEIGHT, "MOTOR DRIVERS");
  nodes[4].AddLink("https://www.robotshop.com/en/cytron-30a-5-30v-single-brushed-dc-motor-driver.html");
  nodes[4].AddLink("https://docs.google.com/document/d/178uDa3dmoG0ZX859rWUOS2Xyafkd8hSsSET5-ZLXMYQ/edit");
  nodes[4].AddLink("https://www.ebay.com.au/itm/DC-DC-15A-Buck-4-32V-12V-to-1-2-32V-5V-Converter-Step-Down-Module-Adjustable-Hot/202129187829?hash=item2f0fd6a3f5%3Ag%3AnEAAAOSw9N1V0vFq");
  nodes[4].AddImage("schematics/MotorDrivers.png");
  nodes[4].AddContents("Motor drivers are used to supply motors with sufficient driving power. They act as current amplifiers \u2013 taking in small current signals and converting them into large current signals which are able to drive motors. The motor drivers used in the rover also include inputs to set the direction of motor rotation (controlled by Raspberry Pi via GPIO pins) and a PWM input to set the motor speed (from PWM driver).\n\nThe motor drivers are connected to Buck Converters, which step down voltage from the LiPo power supply, while stepping up output current to the motor drivers.");
  
  nodes[5] = new Node(5, 1000, 600, NODE_WIDTH, NODE_HEIGHT, "360 DEGREE CAMERA");
  nodes[5].AddLink("https://theta360.com/en/about/theta/s.html");
  nodes[5].AddContents("The Ricoh Theta S is a 360 degree camera which is attached to the top of the rover, permitting the user at the base station a clear view of the area surrouding the rover.\n\nThe camera is connected to the Raspberry Pi via USB, from which it is powered and communicates data. However, the Pi does not do any image processing with the camera image. Instead, a particular program is used to redirect the USB data to other users on the network which, in this case, is the base station. Thus, assuming that the base station is able to communicate with the rover via the onboard radio, the base station is able to see the camera image - irregardless of distance.");
  nodes[5].kicad_enabled = false;
  
  nodes[6] = new Node(6, 1400, 400, NODE_WIDTH, NODE_HEIGHT, "ONBOARD RADIO");
  nodes[6].kicad_enabled = false;
  nodes[6].AddLink("https://www.ubnt.com/airmax/rocketm/");
  nodes[6].AddContents("The rover uses the Rocket M5 radio to establish communication between the base station and the rover.");
  
  nodes[7] = new Node(7, 600, -200, NODE_WIDTH, NODE_HEIGHT, "ARM CONTROLLER");
  nodes[7].AddLink("http://www.pighixxx.com/test/wp-content/uploads/2014/11/nano.png");
  nodes[7].AddImage("schematics/ArmController.png");
  nodes[7].AddContents("An Arduino is used to control the arm. It communicates with the Raspberry Pi over USB via ROS.\n\nThe Arduino controls the PWM signals for each servo/actuator by sending the desired PWM via i2c to the PWM driver and controls motor direction using GPIO output to the motor drivers.");
  
  nodes[8] = new Node(8, 1000, -200, NODE_WIDTH, NODE_HEIGHT, "ARM MOTOR & PWM DRIVERS");
  nodes[8].AddLink("https://www.robotshop.com/en/cytron-13a-5-30v-single-dc-motor-controller.html");
  nodes[8].AddLink("https://www.robotshop.com/media/files/pdf2/cyt-132-v2.3.pdf");
  nodes[8].AddLink("https://www.ebay.com.au/itm/DC-DC-15A-Buck-4-32V-12V-to-1-2-32V-5V-Converter-Step-Down-Module-Adjustable-Hot/202129187829?hash=item2f0fd6a3f5%3Ag%3AnEAAAOSw9N1V0vFq");
  nodes[8].AddImage("schematics/ArmMotorDrivers.png");
  nodes[8].AddContents("The motor drivers are responsible for supply the arm servo and actuators with sufficient driving power. They act as current amplififers - taking in small current signals and converting them into large current signals which are able to drive motors.\n\nThe motor drivers receive direction control signals from the Arduino board and PWM signals from the Arduino-controlled PWM driver.\n\nThe drivers are connected to Buck Converters, which step down voltage from the LiPo power supply, while stepping up output current to the drivers.");
  
  nodes[9] = new Node(9, 1400, -200, NODE_WIDTH, NODE_HEIGHT, "ARM SERVOS & ACTUATORS");
  nodes[9].kicad_enabled = false;
  nodes[9].AddContents("The servos and actuators move the arm to the set position by apply rotational and linear force.\n\n");
}

public void CreateConnectors() {
  connectors[0] = new Connector(0, nodes[0],nodes[1],1,0,0, "USB", 0, 2);
  connectors[1] = new Connector(1, nodes[1],nodes[2],1,3,0, "UART", 0, 3);
  connectors[2] = new Connector(2, nodes[1],nodes[3],2,0,0, "i2c", 1, 1);
  connectors[3] = new Connector(3, nodes[4],nodes[3],2,3,2, "PWM", 1, 2);
  connectors[4] = new Connector(4, nodes[0],nodes[4],2,0,1, "PWR", 0, 1);
  connectors[5] = new Connector(5, nodes[4],nodes[1],1,3,0, "GPIO", 0, 1);
  connectors[6] = new Connector(6, nodes[1],nodes[5],1,3,0, "USB", 0, 3);
  connectors[7] = new Connector(7, nodes[1],nodes[6],1,3,0, "ETHERNET", 0, 1);
  connectors[8] = new Connector(8, nodes[1],nodes[7],0,2,0, "USB", 0, 1);
  connectors[9] = new Connector(9, nodes[7],nodes[8],1,3,0, "i2c", 0, 1);
  connectors[10] = new Connector(10, nodes[8],nodes[9],1,3,1, "PWR", 0, 1);
  connectors[11] = new Connector(11, nodes[7],nodes[8],1,3,0, "GPIO", 1, 1);
}
class Connector {
  final int TEXT_SIZE = 20;
  final float LABEL_X_OFFSET = 10.0f;
  final float LABEL_Y_OFFSET = 20.0f;
  
  Node parent_node1, parent_node2;
  int my_id, position1, position2, num_of_lines;
  float node1_x, node1_y, node2_x, node2_y, x_midpoint, y_midpoint;
  int line_colour = color(100, 100, 100, 255);
  boolean is_visible = true;
  String connector_label;
  int label_position;

  Connector(int id, Node node1, Node node2, int node1_exit_position, int node2_enter_position, int colour, String label, int label_side, int num_lines) {
    parent_node1 = node1;
    parent_node2 = node2;
    position1 = node1_exit_position;
    position2 = node2_enter_position;
    num_of_lines = num_lines;
    my_id = id;
    connector_label = label;
    label_position = label_side;
    node1.connector_id_array[node1.num_of_connectors] = my_id;
    node1.num_of_connectors++;
    node2.connector_id_array[node2.num_of_connectors] = my_id;
    node2.num_of_connectors++;
    
    
    switch(node1_exit_position) {
      case 0:
        node1_x = parent_node1.x_coord;
        node1_y = parent_node1.y_coord-(NODE_HEIGHT/2); 
        break;
      case 1:
        node1_x = parent_node1.x_coord+(NODE_WIDTH/2);
        node1_y = parent_node1.y_coord;
        break;
      case 2:
        node1_x = parent_node1.x_coord;
        node1_y = parent_node1.y_coord+(NODE_HEIGHT/2);
        break;
    }
    
    switch(node2_enter_position) {
      case 0:
        node2_x = parent_node2.x_coord;
        node2_y = parent_node2.y_coord-(NODE_HEIGHT/2);
        break;
      case 2:
        node2_x = parent_node2.x_coord;
        node2_y = parent_node2.y_coord+(NODE_HEIGHT/2);
        break;
      case 3:
        node2_x = parent_node2.x_coord-(NODE_WIDTH/2);
        node2_y = parent_node2.y_coord;
        break;
    }
    
    switch(colour) {
      case 0:
        line_colour = color(100, 100, 100, 255);
        break;
      case 1:
        line_colour = color(255, 87, 87, 255);
        break;
      case 2:
        line_colour = color(255, 133, 51, 255);
    }
  }

  public void UpdatePosition(float delta_x, float delta_y) {
    node1_x += delta_x;
    node1_y += delta_y;
    node2_x += delta_x;
    node2_y += delta_y;
  }

  public void SetTransparency(int alpha) {
    
    line_colour = color(100, 100, 100, alpha);
  
  }
  
  public void Display() {
    if(is_visible) {
      stroke(line_colour);
      strokeWeight(CONNECTOR_THICKNESS);
      textSize(TEXT_SIZE);
      fill(line_colour);
      
      x_midpoint = node1_x+((node2_x-node1_x)/2);
      y_midpoint = node1_y+((node2_y-node1_y)/2);
      
      switch(num_of_lines) {
        case 1:
          if(node1_y==node2_y) {
            textAlign(CENTER, CENTER);
            if(label_position == 0) {
              text(connector_label, x_midpoint, node1_y - LABEL_Y_OFFSET);
            }
            else {
              text(connector_label, x_midpoint, node1_y + LABEL_Y_OFFSET);
            }
          }
          else {
            if(label_position == 0) {
              textAlign(RIGHT, CENTER);
              text(connector_label, x_midpoint - LABEL_X_OFFSET, y_midpoint);
            }
            else {
              textAlign(LEFT, CENTER);
              text(connector_label, x_midpoint + LABEL_X_OFFSET, y_midpoint);
            }            
          }
          
          line(node1_x, node1_y, node2_x, node2_y);
          break;
        case 2:
          textAlign(CENTER, CENTER);
          if(position1 == 1 || position1 == 3) {
            line(node1_x, node1_y, node2_x, node1_y);
            line(node2_x, node1_y, node2_x, node2_y);
            if(label_position == 0) {
              text(connector_label, x_midpoint, node1_y - LABEL_Y_OFFSET);
            }
            else {
              text(connector_label, x_midpoint, node1_y + LABEL_Y_OFFSET);
            }
          }
          else {
            line(node1_x, node1_y, node1_x, node2_y);
            line(node1_x, node2_y, node2_x, node2_y);  
            if(label_position == 0) {
              text(connector_label, x_midpoint, node2_y - LABEL_Y_OFFSET);
            }
            else {
              text(connector_label, x_midpoint, node2_y + LABEL_Y_OFFSET);
            }
          }
          break;
        case 3 :
          line(node1_x, node1_y, x_midpoint, node1_y);
          line(x_midpoint, node1_y, x_midpoint, node2_y);
          line(x_midpoint, node2_y, node2_x, node2_y);  
          if(label_position == 0) {
            textAlign(RIGHT, CENTER);
            text(connector_label, x_midpoint - LABEL_X_OFFSET, y_midpoint);
          }
          else {
            textAlign(LEFT, CENTER);
            text(connector_label, x_midpoint + LABEL_X_OFFSET, y_midpoint);
          }
          break;
      }
    }
  }
}
class Node {
  final int HEADER_SIZE = 26;
  int CONTENTS_SIZE = 18;
  final float TEXTBOX_INSET = 10;
  final int CONTENTS_INSET = 40;
  final int ARROW_TAIL_WIDTH = 40;
  final int ARROW_TAIL_HEIGHT = 14;
  final int ARROW_HEAD_SIDE_LENGTH = 50;
  
  float x_coord, y_coord, rect_width, rect_height;
  float img_x = width/2;
  float img_y = height/2;
  
  float arrow_x = 100;
  float arrow_y = 50;
  
  float arrow_head_x1 = arrow_x-(ARROW_TAIL_WIDTH/2);
  float arrow_head_y1 = arrow_y - (ARROW_HEAD_SIDE_LENGTH/2);
  float arrow_head_x2 = arrow_x-(ARROW_TAIL_WIDTH/2);
  float arrow_head_y2 = arrow_y + (ARROW_HEAD_SIDE_LENGTH/2);
  float arrow_head_x3 = arrow_x-ARROW_HEAD_SIDE_LENGTH-(ARROW_TAIL_WIDTH/2);
  float arrow_head_y3 = arrow_y;
  float arrow_head_gradient_up = (arrow_head_y1 - arrow_head_y3)/(arrow_head_x1 - arrow_head_x3);
  float arrow_head_gradient_down = -1.0f * arrow_head_gradient_up;
  float c_up = arrow_head_y3 - (arrow_head_gradient_up * arrow_head_x3);
  float c_down = arrow_head_y3 - (arrow_head_gradient_down * arrow_head_x3);
  
  float kicad_icon_x = (width/2) + (EXPANDED_SIZE_INCREASE/2) - 35;
  float kicad_icon_y = (height/2) + (EXPANDED_SIZE_INCREASE/2) - 105;
  
  float chrome_icon_x = (width/2) + (EXPANDED_SIZE_INCREASE/2) - 65;
  float chrome_icon_y = (height/2) + (EXPANDED_SIZE_INCREASE/2) - 105;
  
  Connector[] node_connections;
  int num_of_connectors = 0;
  int[] connector_id_array = {-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  
  String[] links = {"", "", "", "", ""};
  int num_of_links = 0;
  PImage my_img;
  String node_contents;
  
  int alpha = 255;
  int my_id;
  String node_name;
  int border_colour = color(100, 100, 100, alpha);
  boolean mouse_is_over = false;
  boolean node_activated = false;
  boolean block_at_centre = false;
  boolean expand_node = false;
  boolean reduce_node = false;
  boolean display_image = false;
  boolean node_expanded = false;
  boolean mouse_over_kicad = false;
  boolean mouse_over_chrome = false;
  boolean mouse_over_arrow = false;
  boolean schematic_enabled = true;
  boolean kicad_enabled = true;

  Node(int id, float x, float y, float w, float h, String name) {
    my_id = id;
    x_coord = x;
    y_coord = y;
    rect_width = w;
    rect_height = h;
    node_name = name;
    img_x = width/2;
    img_y = height/2;
    
  }

  public void AddLink(String link) {
    links[num_of_links] = link;
    num_of_links++;
  }
  
  public void AddImage(String link) {
    my_img = loadImage(link);
  }
  
  public void OpenLinks() {
    for(int i = 0; i < num_of_links; i++) {
      link(links[i]);
    }
  }

  public boolean MouseIsInsideNode() {
    if ((mouseX > (x_coord-(rect_width/2))) && (mouseX < (x_coord+(rect_width/2)))
        && (mouseY > (y_coord-(rect_height/2))) && (mouseY < (y_coord+(rect_height/2)))) {
          return true;
    }
    else {
      return false;
    }
  }
  
  public boolean MouseIsOverIcon(float icon_x, float icon_y) {
    if((mouseX > (icon_x)) && (mouseX < (icon_x+25))
        && (mouseY > (icon_y)) && (mouseY < (icon_y+25))) {
          return true;
        }
        else {
          return false;
        }
  }
  
  public boolean MouseIsOverArrow() {
    if(((mouseX > (arrow_head_x3)) && (mouseX < (arrow_head_x1))
        && (mouseY < ((arrow_head_gradient_down*mouseX)+c_down)) && (mouseY > ((arrow_head_gradient_up*mouseX)+c_up)))
        || ((mouseX > (arrow_x - (ARROW_TAIL_WIDTH/2))) && (mouseX < (arrow_x + (ARROW_TAIL_WIDTH/2))))
        && (mouseY > (arrow_y - (ARROW_TAIL_HEIGHT/2))) && (mouseY < (arrow_y + (ARROW_TAIL_HEIGHT/2)))) {
          return true;
        }
        else {
          return false;
        }
  }
  
  public void ShareImage(Node node) {
    my_img = node.my_img;
  }

  public void CheckRollover() {
    if(global_lock_disabled) {
      if (MouseIsInsideNode()) {
        border_colour = color(50, 50, 50, alpha);
        mouse_is_over = true;
      }
      else {
        border_colour = color(100, 100, 100, alpha);
        mouse_is_over = false;
      }
    }
    else {
      if(display_image) {
        mouse_over_arrow = MouseIsOverArrow();
      }
      else {
        mouse_over_kicad = MouseIsOverIcon(kicad_icon_x, kicad_icon_y);
        mouse_over_chrome = MouseIsOverIcon(chrome_icon_x, chrome_icon_y);
      }
    }
  }
  
  public void UpdatePosition(float delta_x, float delta_y) {
    x_coord += delta_x;
    y_coord += delta_y;
  }
  
  public void UpdateImagePosition(float delta_x, float delta_y) {
    img_x += delta_x;
    img_y += delta_y;
  }
  
  public void SetTransparency(int value) {
    alpha = value;
    border_colour = color(100, 100, 100, alpha);
  }
  
  public void AddContents(String contents) {
    node_contents = contents;
  }

  public void Display() {
    if(node_activated && !block_at_centre) {
      float x_diff, y_diff;
      
      float x_modifier = 1.0f;
      float y_modifier = 1.0f;
      int axis_in_position = 0;
      
      x_diff = (width/2) - x_coord;
      if(x_diff < 0)
      {
        x_modifier = -1.0f;
      }
      
      y_diff = (height/2) - y_coord;
      if(y_diff < 0)
      {
        y_modifier = -1.0f;
      }
      
      if((abs(x_diff) - EXPAND_MOVE_STEP)>=0) {
        x_diff = x_modifier * EXPAND_MOVE_STEP;
      }
      else {
        axis_in_position++;
      }
      
      if((abs(y_diff) - EXPAND_MOVE_STEP)>=0) {
        y_diff = y_modifier * EXPAND_MOVE_STEP;
      }
      else {
        axis_in_position++;
      }
      
      UpdatePositions(x_diff, y_diff);
      
      if(axis_in_position == 2) {
        block_at_centre = true;
        expand_node = true;
      }
    }
    else if(block_at_centre && expand_node) {
        if(rect_width < EXPANDED_SIZE_INCREASE) {
          rect_width += EXPAND_WIDTH_STEP;
          rect_height += EXPAND_HEIGHT_STEP;
        }
        else {
          expand_node = false;
          node_expanded = true;
        }
    }
    else if(block_at_centre && reduce_node) {
        if(rect_width > NODE_WIDTH) {
          rect_width -= EXPAND_WIDTH_STEP;
          rect_height -= EXPAND_HEIGHT_STEP;
        }
        else {
          reduce_node = false;
          node_activated = false;
          global_lock_disabled = true;
          block_at_centre = false;
          for (int i = 0; i < connector_id_array.length; i++) {
            if(connector_id_array[i] == -1)
            {
              break;
            }
            else {
              connectors[connector_id_array[i]].is_visible = true;
            }
          }
        }
    }
    rectMode(CENTER);
    if(node_activated && block_at_centre) {
      strokeWeight(8);
      fill(255, 255, 255, 232);
    }
    else {
      strokeWeight(NODE_BORDER_THICKNESS);
      fill(255, 255, 255, 0);

    }
    stroke(border_colour);
    rect(x_coord, y_coord, rect_width, rect_height);
    if(!node_activated) {
      textAlign(CENTER, CENTER);
      textSize(HEADER_SIZE);
      fill(border_colour);

      text(node_name, x_coord, y_coord, (rect_width - TEXTBOX_INSET), (rect_width - TEXTBOX_INSET));
    }
    else {
      if(node_expanded) {
        imageMode(CORNER);
        if(kicad_enabled) {
          if(mouse_over_kicad) {
            image(kicad_img, kicad_icon_x, kicad_icon_y);
          }
          else {
            image(kicad_img_gray, kicad_icon_x, kicad_icon_y);
          }
        }
        else {
          tint(255,0,0,150);
          image(kicad_img, kicad_icon_x, kicad_icon_y);
          noTint();
        }
        if(mouse_over_chrome) {
          image(chrome_img, chrome_icon_x, chrome_icon_y);
        }
        else {
          image(chrome_img_gray, chrome_icon_x, chrome_icon_y);
        }
        textAlign(CENTER, CENTER);
        textSize(CONTENTS_SIZE);
        fill(border_colour);
        text(node_contents, x_coord, y_coord, (rect_width - CONTENTS_INSET), (rect_height - CONTENTS_INSET));
      }
    }
    if(display_image) {
      imageMode(CENTER);
      background(255);
      image(my_img, img_x, img_y);
      rectMode(CENTER);
      noStroke();
      if(mouse_over_arrow) {
        fill(150,150,150,200);
      }
      else {
        fill(200,200,200,100);  
      }
      
      rect(arrow_x, arrow_y, ARROW_TAIL_WIDTH, ARROW_TAIL_HEIGHT);
      triangle(arrow_head_x1, arrow_head_y1, arrow_head_x2, arrow_head_y2, arrow_head_x3, arrow_head_y3);
    }
  }
}
  public void settings() {  size(1280, 720);  smooth(4); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "CircuitBlockDiagram" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
